The following files are included in this directory:

ZorkProject.pdf: an overview of the entire project. The different step assignments will refer to this.

sample.xml and samplepack.zip contain xml files that are descriptions of dungeons that you will use for testing and demoing your project.

DungeonExplained.pdf gives an overview of the information contained in sample.xml.

studentActivity.xml -- we will reduce an example of an XML parser, and the file in this zip file (studentActivity.xml) will be used in that example. 