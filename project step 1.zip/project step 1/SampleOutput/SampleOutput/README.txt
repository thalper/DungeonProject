This folder contains two files that show the output from the parser for our implementation in different formats. This is provided to give you an idea of how the general format of your output should look -- you should not spend time getting it to look exactly like this in terms of format, etc. What is important is that you show the elements in the .xml file that you are recognizing.

The file ConstructorAndSetterOutput.txt shows the output from having constructors and setters print when they are invoked. Because of the way the parser works, you may have a different order than what is shown here, but all elements should be shown.

MapPrintOutput.txt shows a more structured output. 