#include "attack.h"

Attack::Attack()    {
    count = 0;
}

Attack::~Attack()   {
    for (Condition* condition : conditions)
        delete condition;
}

void Attack::setPrint(std::string print) {
	this->Print = print;
}

void Attack::addCondition(Condition* condition)    {
    conditions.push_back(condition);
    count += 1;
}

void Attack::addAction(std::string action)  {
    actions.push_back(action);
}

std::string Attack::getPrint()  {
    return Print;
}

std::vector<Condition*> Attack::getConditions() {
    return conditions;
}

std::vector<std::string> Attack::getActions()   {
    return actions;
}

bool Attack::hasConditions()    {
    if (count > 0)
        return true;
    return false;
}


