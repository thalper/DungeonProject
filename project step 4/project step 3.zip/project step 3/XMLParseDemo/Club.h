#pragma once
#include "Activity.h"

class Club : public Activity {
public:
	virtual void printData(std::string prefix);
};

